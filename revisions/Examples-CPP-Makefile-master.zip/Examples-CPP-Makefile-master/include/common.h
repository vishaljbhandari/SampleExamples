# ifndef COMMON_H
# define COMMON_H

# include <iostream>
# include <stdlib.h>
# include <stdio.h>
# include <string.h>

# endif
