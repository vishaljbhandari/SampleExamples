# ifndef _SAMPLE_H_
# define _SAMPLE_H_
# include "common.h"

#endif // _SAMPLE_H_
