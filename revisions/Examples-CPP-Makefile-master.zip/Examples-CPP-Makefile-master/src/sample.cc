# include "include/sample.h"
int main (int argc, char* argv[])
{
        puts("This is sample program with generic make file");
        return 0;
}
